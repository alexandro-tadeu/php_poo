<?php include("includes/header.php"); ?>

<div class="contest">
    <?php
    include("Class/ClassConexao.php");
    include("Class/ClassCrud.php");
    $Crud=new ClassCrud();
    ?>
</div>

<?php    include("includes/footer.php"); ?>
