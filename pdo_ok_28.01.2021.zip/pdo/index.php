<?php include("header.php"); ?>
    <div class="Content">
        <?php
            include("ClassConexao.php");
            include("ClassCrud.php");
            $Crud=new ClassCrud();
        ?>
    </div> 
    <!-- Footer.php -->

<?php include("footer.php"); ?>