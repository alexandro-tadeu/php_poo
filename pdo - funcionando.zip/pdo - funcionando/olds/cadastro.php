<?php include("includes/header.php"); ?>

<div class="Content">

    <div class="Content">
        <?php include("includes/FormularioCadastro.php");?>
    </div>

</div>

<?php include("includes/footer.php"); ?>
