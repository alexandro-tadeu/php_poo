<?php include("header.php"); ?>

<div class="Content">

<?php include("FormularioCadastro.php"); ?>    
</div>

<?php include("footer.php"); ?>