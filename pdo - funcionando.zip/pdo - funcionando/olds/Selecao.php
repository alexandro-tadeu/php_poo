<?php 
include("includes/header.php"); 

?>

<div class="Content">

        <?php include("class/ClassCrud.php");?>
    </div>
<table class="TabelaCrud">
     <tr>
         <td>Nome</td>
         <td>Sexo</td>
         <td>Cidade</td>
         <td>Ações</td>
     </tr>

    
</table>
</div>

<?php include("includes/footer.php"); ?>
